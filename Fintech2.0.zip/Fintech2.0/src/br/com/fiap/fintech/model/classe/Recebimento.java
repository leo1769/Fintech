package br.com.fiap.fintech.model.classe;

public class Recebimento extends Transacao {

    public Recebimento() {
    }

    public Recebimento(double valor, String descricao) {
        super(valor, descricao);
    }

}
