package br.com.fiap.fintech.model.classe;

public class Gastos extends Transacao {

    public Gastos() {
    }
    public Gastos(double valor, String descricao) {
        super(valor, descricao);
    }
}
